<?php
/**
 * Featured badge template
 */

echo $this->_get_badge_image();
