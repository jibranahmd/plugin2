<?php
/**
 * Slider wrap end template
 */
?></div>
</div>
