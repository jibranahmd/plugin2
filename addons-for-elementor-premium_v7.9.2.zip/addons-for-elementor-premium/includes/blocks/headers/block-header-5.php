<?php

namespace LivemeshAddons\Blocks\Headers;

class LAE_Block_Header_5 extends LAE_Block_Header {

    function get_block_header_class() {

        return 'lae-block-header-5';

    }
}